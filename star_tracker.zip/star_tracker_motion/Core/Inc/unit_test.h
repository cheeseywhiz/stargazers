/*
 * unit_test.h
 *
 *  Created on: Apr 11, 2022
 *      Author: broml
 */

#ifndef INC_UNIT_TEST_H_
#define INC_UNIT_TEST_H_

void run_tests(void);

#endif /* INC_UNIT_TEST_H_ */
